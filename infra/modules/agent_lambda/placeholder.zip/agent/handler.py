"""
FinOps Agent — placeholder Lambda handler.
This stub is replaced in Phase 2 by src/agent/handler.py.
"""
import json
import logging

logger = logging.getLogger()
logger.setLevel("INFO")


def lambda_handler(event, context):
    logger.info("FinOps Agent placeholder handler invoked", extra={"event": event})
    return {
        "statusCode": 200,
        "body": json.dumps({
            "status": "placeholder",
            "message": "Phase 2 handler not yet deployed.",
        }),
    }
